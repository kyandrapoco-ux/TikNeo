const axios = require('axios');

module.exports = async (req, res) => {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }
    
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }
    
    const { url } = req.body;
    
    if (!url) {
        return res.status(400).json({ error: 'URL is required' });
    }
    
    if (!url.includes('tiktok.com') && !url.includes('vt.tiktok.com')) {
        return res.status(400).json({ error: 'Invalid TikTok URL' });
    }
    
    try {
        const response = await axios.get('https://tikwm.com/api/', {
            params: { url: url, hd: 1 },
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const data = response.data;
        
        if (data.code !== 0) {
            throw new Error(data.msg || 'Failed to fetch video');
        }
        
        const videoData = data.data;
        
        // Cari link HD terbaik
        let hdLink = videoData.hd || videoData.wmplay || videoData.play || '';
        if (hdLink && !hdLink.includes('hd') && videoData.wmplay && videoData.wmplay.includes('hd')) {
            hdLink = videoData.wmplay;
        }
        
        // Extract hashtags
        const title = videoData.title || videoData.desc || '';
        const hashtags = [];
        const hashtagMatches = title.match(/#[\w\u0590-\u05fe\u0600-\u06ff]+/g);
        if (hashtagMatches) {
            hashtagMatches.forEach(tag => {
                hashtags.push(tag.substring(1));
            });
        }
        
        res.json({
            success: true,
            code: 200,
            data: {
                author: {
                    username: videoData.author?.unique_id || videoData.unique_id || 'user',
                    nickname: videoData.author?.nickname || videoData.nickname || 'TikTok User',
                    avatar: videoData.author?.avatar || videoData.avatar || ''
                },
                video: {
                    id: videoData.id || '',
                    title: title,
                    cover: videoData.cover || '',
                    duration: videoData.duration || 0,
                    playCount: videoData.play_count || 0,
                    likeCount: videoData.digg_count || 0
                },
                downloads: {
                    noWatermark: videoData.play || videoData.wm || '',
                    hd: hdLink,
                    music: videoData.music || ''
                },
                hashtags: hashtags.slice(0, 10)
            }
        });
        
    } catch (error) {
        console.error('Error:', error.message);
        res.status(500).json({ 
            success: false, 
            error: 'Failed to process video',
            message: error.message 
        });
    }
};