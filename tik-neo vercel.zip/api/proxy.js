const axios = require('axios');

module.exports = async (req, res) => {
    const { url } = req.query;
    
    if (!url) {
        return res.status(400).json({ error: 'URL required' });
    }
    
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream',
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const contentType = response.headers['content-type'];
        const isVideo = contentType?.includes('video') || url.includes('.mp4');
        
        if (isVideo) {
            res.setHeader('Content-Disposition', `attachment; filename="tiktok_${Date.now()}.mp4"`);
        } else if (contentType?.includes('audio')) {
            res.setHeader('Content-Disposition', `attachment; filename="tiktok_audio_${Date.now()}.mp3"`);
        }
        
        res.setHeader('Content-Type', contentType || 'application/octet-stream');
        
        response.data.pipe(res);
        
    } catch (error) {
        console.error('Proxy error:', error.message);
        res.status(500).json({ error: 'Download failed', message: error.message });
    }
};