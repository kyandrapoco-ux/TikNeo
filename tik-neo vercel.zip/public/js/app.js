// Konfigurasi API
const API_BASE_URL = '/api';

// Variabel global
let currentDownloadLinks = {
    noWatermark: '',
    hd: '',
    music: ''
};
let currentAuthorUsername = '';

// DOM Elements
const form = document.getElementById('downloadForm');
const urlInput = document.getElementById('urlInput');
const pasteBtn = document.getElementById('pasteBtn');
const resultArea = document.getElementById('resultArea');
const statusText = document.getElementById('statusText');
const downloadModal = document.getElementById('downloadModal');
const videoPreview = document.getElementById('videoPreview');
const previewPlayer = document.getElementById('previewPlayer');
const previewSource = document.getElementById('previewSource');

// Toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="flex items-center gap-3">
            <i class="fa ${type === 'success' ? 'fa-check-circle text-green-400' : type === 'error' ? 'fa-exclamation-triangle text-red-400' : 'fa-info-circle text-blue-400'} text-xl"></i>
            <span class="text-sm">${message}</span>
        </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Loading state
function setLoading(isLoading) {
    const btn = form.querySelector('button[type="submit"]');
    if (isLoading) {
        btn.innerHTML = '<i class="fa fa-spinner fa-spin-custom mr-2"></i> LOADING...';
        btn.disabled = true;
    } else {
        btn.innerHTML = '<i class="fa fa-download mr-2"></i> DOWNLOAD NOW';
        btn.disabled = false;
    }
}

// Download video melalui proxy
async function downloadViaProxy(url, filename) {
    if (!url) {
        showToast('Link tidak tersedia!', 'error');
        return false;
    }
    
    try {
        showToast(`Mengunduh ${filename}...`, 'info');
        window.open(`${API_BASE_URL}/proxy?url=${encodeURIComponent(url)}`, '_blank');
        return true;
    } catch (error) {
        console.error('Download error:', error);
        showToast('Gagal memulai download', 'error');
        return false;
    }
}

// Fetch data dari API
async function fetchVideoData(url) {
    setLoading(true);
    statusText.classList.remove('hidden');
    statusText.innerHTML = '<i class="fa fa-spinner fa-spin-custom mr-1"></i> Mengambil data video...';
    
    try {
        const response = await fetch(`${API_BASE_URL}/download`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url })
        });
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'Gagal mengambil data');
        }
        
        // Update data
        const videoData = data.data;
        currentDownloadLinks = videoData.downloads;
        currentAuthorUsername = videoData.author.username;
        
        // Update UI
        document.getElementById('authorAvatar').src = videoData.author.avatar || 'https://via.placeholder.com/64';
        document.getElementById('authorName').textContent = videoData.author.nickname;
        document.getElementById('authorUsername').textContent = `@${videoData.author.username}`;
        document.getElementById('captionText').textContent = videoData.video.title;
        
        // Update TikTok link
        const tiktokLink = document.getElementById('tiktokLink');
        tiktokLink.href = `https://tiktok.com/@${videoData.author.username}`;
        
        // Hashtags
        const tagsContainer = document.getElementById('hashtagsContainer');
        tagsContainer.innerHTML = '';
        if (videoData.hashtags && videoData.hashtags.length > 0) {
            videoData.hashtags.forEach(tag => {
                const span = document.createElement('span');
                span.className = 'tag';
                span.innerText = '#' + tag;
                tagsContainer.appendChild(span);
            });
        }
        
        // Background blur
        if (videoData.video.cover) {
            document.getElementById('bgImage').src = videoData.video.cover;
            document.getElementById('bgBlur').style.opacity = '1';
        }
        
        // Preview video
        if (currentDownloadLinks.noWatermark) {
            previewSource.src = currentDownloadLinks.noWatermark;
            previewPlayer.load();
            videoPreview.classList.remove('hidden');
        }
        
        // Tampilkan hasil
        resultArea.classList.remove('hidden');
        statusText.innerHTML = '✅ Data berhasil dimuat!';
        
        setTimeout(() => {
            statusText.classList.add('hidden');
        }, 2000);
        
        showToast('Video berhasil dimuat!', 'success');
        
    } catch (error) {
        console.error('Error:', error);
        showToast(error.message || 'Gagal memuat video', 'error');
        statusText.innerHTML = '❌ Gagal memuat data';
        setTimeout(() => {
            statusText.classList.add('hidden');
        }, 3000);
    } finally {
        setLoading(false);
    }
}

// Event Listeners
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const url = urlInput.value.trim();
    
    if (!url) {
        showToast('Masukkan link TikTok terlebih dahulu!', 'error');
        return;
    }
    
    if (!url.includes('tiktok.com') && !url.includes('vt.tiktok.com')) {
        showToast('Link tidak valid! Pastikan link dari TikTok', 'error');
        return;
    }
    
    await fetchVideoData(url);
    downloadModal.classList.remove('hidden');
});

// Paste button
pasteBtn.addEventListener('click', async () => {
    try {
        const text = await navigator.clipboard.readText();
        urlInput.value = text;
        urlInput.dispatchEvent(new Event('input'));
        showToast('Link berhasil di-paste!', 'success');
    } catch (err) {
        showToast('Gagal mengambil clipboard', 'error');
    }
});

// Auto detect URL
let typingTimer;
urlInput.addEventListener('input', function() {
    const url = this.value.trim();
    if ((url.includes('tiktok.com') || url.includes('vt.tiktok.com')) && url.length > 20) {
        statusText.classList.remove('hidden');
        statusText.innerHTML = '√ Link detected, menunggu untuk mengunduh...';
        clearTimeout(typingTimer);
        typingTimer = setTimeout(() => {
            statusText.classList.add('hidden');
        }, 1500);
    } else {
        statusText.classList.add('hidden');
    }
});

// Download buttons
document.getElementById('dlMp3').addEventListener('click', () => {
    downloadModal.classList.add('hidden');
    downloadViaProxy(currentDownloadLinks.music, 'tiktok_audio.mp3');
});

document.getElementById('dlNoWm').addEventListener('click', () => {
    downloadModal.classList.add('hidden');
    downloadViaProxy(currentDownloadLinks.noWatermark, 'tiktok_video.mp4');
});

document.getElementById('dlAi').addEventListener('click', () => {
    downloadModal.classList.add('hidden');
    const hdLink = currentDownloadLinks.hd || currentDownloadLinks.noWatermark;
    downloadViaProxy(hdLink, 'tiktok_hd.mp4');
});

// Close modal
document.getElementById('closeModal').addEventListener('click', () => {
    downloadModal.classList.add('hidden');
});
document.getElementById('modalOverlay').addEventListener('click', () => {
    downloadModal.classList.add('hidden');
});

// Visitor counter sederhana
function updateVisitorCount() {
    const count = localStorage.getItem('tikneo_visitor');
    if (!count) {
        localStorage.setItem('tikneo_visitor', '1');
        document.getElementById('visitorCount').innerText = '1';
    } else {
        const newCount = parseInt(count) + 1;
        localStorage.setItem('tikneo_visitor', newCount);
        document.getElementById('visitorCount').innerText = newCount > 999 ? Math.floor(newCount/1000) + 'K' : newCount;
    }
}
updateVisitorCount();

console.log('TikNeo☄️');